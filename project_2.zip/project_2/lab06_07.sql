--LAB 06 
-- Part 1A
select "Director"."FirstName" as "First_Name", "Director"."LastName" as "Last_Name"
from "Director"
where "Director"."Country" = 'Canada';

-- Part 1B
select "DirectorCast"."MovieName"
from "DirectorCast" inner join "Director" on "DirectorCast"."DirectorID" = "Director"."DirectorID"
where "Director"."FirstName" = 'David' and "Director"."LastName" = 'Lynch';

-- Part 1C
select "Movie"."MovieName", "Actor"."FirstName", "Actor"."LastName", "Movie"."Budget" as "Budget_in_USD", "Movie"."Budget"*1.35 as "Budget_in_CAD", "Movie"."Budget"*138.82 as "Budget_in_JPY", "Movie"."Budget"*60.55 as "Budget_in_RUB", "Movie"."Budget"*0.96 as "Budget_in_EUR", "Movie"."Budget"*0.94 as "Budget_in_CHF"
from "Movie", "MovieCast", "Actor"
where "Movie"."MovieName" = "MovieCast"."MovieName" and "Movie"."ReleaseDate" = "MovieCast"."ReleaseDate"
and "MovieCast"."ActorID" = "Actor"."ActorID" and "Movie"."Budget" > 1000000;

-- Part 1D
select "Director"."FirstName", "Director"."LastName"
from "Director"
where "Director"."LastName" like 'A%' ;
select "Director"."FirstName", "Director"."LastName"
from "Director"
where "Director"."LastName" like 'D%';

-- Part 1F
select "Actor"."LastName" , "Actor"."LastName"
from "Actor" 
where "eyecolour" = 'Blue' 

--Lab07
-- Part 2
--Part 2A
SELECT avg(2022 - EXTRACT(year from "DateOfBirth"))
from "Actor"

--Part 2B
select count(distinct "Actor"."Country")
from "Actor" inner join "MovieCast" on "Actor"."ActorID" ="MovieCast"."ActorID"
where "MovieCast"."MovieName" = 'spiderman';

--part 2C
select count (eyecolour)
from "Actor"
where (eyecolour) = 'green'

--part 2D
select count("MovieCast"."MovieName")
from "MovieCast" inner join "Actor" on "MovieCast"."ActorID" = "Actor"."ActorID"
where "Actor"."FirstName"= 'Pitt'and "Actor"."LastName" = 'Brad'



--Part 2E
Select min("Budget"),avg("Budget") , max("Budget")
from "Movie"
